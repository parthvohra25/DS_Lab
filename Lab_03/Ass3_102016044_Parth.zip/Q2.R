m <- 1
n <- 10
x <- seq(1,n)
y <- seq(m, n, by = 0.6)
print(x)
print(y)