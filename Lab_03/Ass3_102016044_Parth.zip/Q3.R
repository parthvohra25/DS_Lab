d <-seq(1:50)
print(cut(d,breaks=10))
print(d)