A <- c(23, 34 ,56,3 ,0, 0 ) 
B <- c('c','b','a')
print(A)
print(B)
